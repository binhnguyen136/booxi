<?php
// silence is golden... so they say
?>