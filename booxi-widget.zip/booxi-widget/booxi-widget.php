<?php
/**
 * @package booxi_widget
 * @version 0.1
 */
/*
Plugin Name: booxi widget
Plugin URI:  https://www.booxi.com
Description: Plugin to give your wordpress site online booking
Version:     0.1
Author:      booxi
Author URI:  https://www.booxi.com
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
Text Domain: booxi-widget
*/

// don't access directly
if (!function_exists('add_action'))
    exit();


class booxi_book_now_widget extends WP_Widget
{

    function __construct()
    {
        parent::__construct('booxi_book_now_widget', __('Booxi Book Now', 'booxi widget' ),
            array ('description' => __( 'Adds a book now widget', 'booxi widget' ))
        );
    }

    function form( $instance )
    {
        $defaults = array(
            'api_key' => get_option('booxi_set_api_key'),
            'button_lang' => get_option('booxi_set_def_lang'),
            'button_label' => get_option('booxi_set_def_label'),

        );
        $api_key = ($instance[ 'api_key' ] == '') ? $defaults ['api_key'] : $instance[ 'api_key' ];
        $button_lang = ($instance[ 'button_lang' ] == '') ? $defaults ['button_lang'] : $instance[ 'button_lang' ];
        $button_label = ($instance[ 'button_label' ] == '') ? $defaults ['button_label'] : $instance[ 'button_label' ];

        // markup for form
        ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'api_key' ); ?>">Booxi Api Key</label>
            <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'api_key' ); ?>" placeholder="Enter your API key" name="<?php echo $this->get_field_name( 'api_key' ); ?>" value="<?php echo esc_attr( $api_key ); ?>">
            <label for="<?php echo $this->get_field_id( 'button_lang' ); ?>">Button Language</label>
            <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'button_lang' ); ?>" name="<?php echo $this->get_field_name( 'button_lang' ); ?>" value="<?php echo esc_attr( $button_lang ); ?>">
            <label for="<?php echo $this->get_field_id( 'button_label' ); ?>">Button Text</label>
            <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'button_label' ); ?>" name="<?php echo $this->get_field_name( 'button_label' ); ?>" value="<?php echo esc_attr( $button_label ); ?>">
        </p>

        <?php
    }

    function update( $new_instance, $old_instance )
    {
        $instance = $old_instance;
        $instance[ 'api_key' ] = strip_tags( $new_instance[ 'api_key' ] );
        $instance[ 'button_lang' ] = strip_tags( $new_instance[ 'button_lang' ] );
        $instance[ 'button_label' ] = strip_tags( $new_instance[ 'button_label' ] );
        return $instance;
    }

    function widget( $args, $instance )
    {

        $api_key = ($instance[ 'api_key' ] == '') ? get_option('booxi_set_api_key') : $instance[ 'api_key' ];
        $button_lang = ($instance[ 'button_lang' ] == '') ? get_option('booxi_set_def_lang') : $instance[ 'button_lang' ];
        $button_label = ($instance[ 'button_label' ] == '') ? get_option('booxi_set_def_label') : $instance[ 'button_label' ];


        /*
        $output = '';

        $output .= '<div class="bx_book_btn">';
        $output .= '<div class="bxe_book_button" data-lang="'.$button_lang.'" data-key="'.$api_key.'" onclick="bxe_core.clickBMW(this);">';
        $output .= '<div class="button_inner">';
        $output .= '<span>'.$button_label.'</span>';
        $output .= '</div>';
        $output .= '<div class="ico">';
        $output .= '<div class="ico_inner"></div>';
        $output .= '</div>';
        $output .= '</div>';
        $output .= '</div>';
        */

        $output = '<div class="bxw_button" data-lang="'.$button_lang.'" data-key="'.$api_key.'" onclick="bxe_core.clickBMW(this);" ico>';
        $output .= $button_label;
        $output .= '</div>';


        ?>
        <aside class="widget widget_archive">
            <?php echo $output; ?>
        </aside>
        <?php
    }

} // END WIDGET

function booxi_register_book_now_widget()
{
    register_widget( 'booxi_book_now_widget' );
}

add_action( 'widgets_init', 'booxi_register_book_now_widget' );

if(!class_exists('booxi_api'))
{
    ////////////////
    class booxi_api
    {
        private $path = '';


        public function __construct()
        {
            $this->init_setting_values();

            $this->path = dirname(__FILE__);

            add_action('admin_init', array(&$this, 'admin_init'));
            add_action('admin_menu', array(&$this, 'add_menu'));

            add_action('wp_head', array(&$this, 'hook_css'));
            add_action('wp_head', array(&$this, 'hook_js'));
            add_action('wp_footer', array(&$this, 'hook_js_init'));

            add_action( 'admin_enqueue_scripts', array(&$this, 'mw_enqueue_color_picker') );


            add_shortcode( 'book-now-button', array(&$this, 'short_book_now_button'));
        }

        function mw_enqueue_color_picker( $hook_suffix ) {
            // first check that $hook_suffix is appropriate for your admin page
            wp_enqueue_style( 'wp-color-picker' );
            wp_enqueue_script( 'my-script-handle', plugins_url('assets/my-script.js', __FILE__ ), array( 'wp-color-picker' ), false, true );
        }

        private function init_setting_values()
        {
            if(get_option( 'booxi_set_api_key' ) === false)    add_option( 'booxi_set_api_key', '');
            if(get_option( 'booxi_set_def_lang' ) === false)   add_option( 'booxi_set_def_lang', 'eng');
            if(get_option( 'booxi_set_def_label' ) === false)  add_option( 'booxi_set_def_label', 'Book Now');
            if(get_option( 'booxi_set_ext_window' ) === false) add_option( 'booxi_set_ext_window', 'false');
            if(get_option( 'booxi_set_show_icon' ) === false)  add_option( 'booxi_set_show_icon', 'true');
            if(get_option( 'booxi_set_font_size' ) === false)  add_option( 'booxi_set_border_radius', '3');
            if(get_option( 'booxi_set_font_size' ) === false)  add_option( 'booxi_set_font_size', '18');
            if(get_option( 'booxi_set_height' ) === false)     add_option( 'booxi_set_height', '40');
            if(get_option( 'booxi_set_padding' ) === false)    add_option( 'booxi_set_padding', '20');
            if(get_option( 'booxi_set_col_text' ) === false)   add_option( 'booxi_set_col_text', 'ffffff');
            if(get_option( 'booxi_set_col_bkg' ) === false)    add_option( 'booxi_set_col_bkg', '4ed066');
            if(get_option( 'booxi_set_col_border' ) === false) add_option( 'booxi_set_col_border', '308c42');

            if(get_option( 'booxi_set_custom_css' ) === false) add_option( 'booxi_set_custom_css', '');

            if(get_option( 'booxi_set_col_text' ) === false)   add_option( 'booxi_set_hov_col_text', 'ffffff');
            if(get_option( 'booxi_set_col_bkg' ) === false)    add_option( 'booxi_set_hov_col_bkg', '3ebd55');
            if(get_option( 'booxi_set_col_border' ) === false) add_option( 'booxi_set_hov_col_border', '38AC4E');

            if(get_option( 'booxi_set_hov_custom_css' ) === false) add_option( 'booxi_set_hov_custom_css', '');
        }


        /**
         * hook into WP's admin_init action hook
         */
        public function admin_init()
        {
            $this->init_settings();
        }

        /**
         * Initialize some custom settings
         */
        public function init_settings()
        {
            // register the settings for this plugin
            register_setting('booxi_api-group', 'booxi_set_api_key');
            register_setting('booxi_api-group', 'booxi_set_def_lang');
            register_setting('booxi_api-group', 'booxi_set_def_label');
            register_setting('booxi_api-group', 'booxi_set_ext_window');

            register_setting('booxi_api-group', 'booxi_set_show_icon');
            register_setting('booxi_api-group', 'booxi_set_border_radius');
            register_setting('booxi_api-group', 'booxi_set_font_size');
            register_setting('booxi_api-group', 'booxi_set_height');
            register_setting('booxi_api-group', 'booxi_set_padding');
            register_setting('booxi_api-group', 'booxi_set_col_text');
            register_setting('booxi_api-group', 'booxi_set_col_bkg');
            register_setting('booxi_api-group', 'booxi_set_col_border');
            register_setting('booxi_api-group', 'booxi_set_custom_css');

            register_setting('booxi_api-group', 'booxi_set_hov_col_text');
            register_setting('booxi_api-group', 'booxi_set_hov_col_bkg');
            register_setting('booxi_api-group', 'booxi_set_hov_col_border');
            register_setting('booxi_api-group', 'booxi_set_hov_custom_css');
        } // END public function init_custom_settings()


        /**
         * add a menu
         */
        public function add_menu()
        {
            add_options_page('booxi Api Settings', 'booxi Api', 'manage_options', 'booxi_api', array(&$this, 'plugin_settings_page'));
        } // END public function add_menu()

        /**
         * Menu Callback
         */
        public function plugin_settings_page()
        {
            if(!current_user_can('manage_options'))
            {
                wp_die(__('You do not have sufficient permissions to access this page.'));
            }

            // Render the settings template
            include(sprintf("%s/admin/settings.php", dirname(__FILE__)));
        } // END public function plugin_settings_page()


        public function hook_css()
        {
            //$output = '<link rel="stylesheet" type="text/css" href="https://www.booxi.com/api/style.css">';
            //echo $output;

            include $this->path . '/assets/dynamic_css.php';
        }

        public function hook_js()
        {
            $output = '<script language="javascript" type="text/javascript" src="https://www.booxi.com/api/bxe_core.js"></script>';

            echo $output;
        }

        public function hook_js_init()
        {

            $bxExtWin = (get_option( 'booxi_set_ext_window' ) == 'true') ? 'true' : 'false';

            $output='<script>

            window.bxApiInit =
                function()
                {
                    console.log("bxApiInit Called!@!!");
                    bxe_core.init({
                    bxLang: "eng",
                    bxExtWin: '.$bxExtWin.'
                    });
                };
            </script>
            <div id="bx-viewport"></div>';

            echo $output;
        }


        public function hook_draw_button()
        {
            $output='<div class="bx_book_btn" data-lang="fre" data-key="2zjqOA6u17hU16Y7I6i89s67m1819JJ5"></div>';

            echo $output;
        }

        function short_book_now_button( $atts )
        {
            $book_now_atts = shortcode_atts( array(
                'api_key' => '',
                'lang' => '',
                'button_text' => ''
            ), $atts );


            $lang = ($book_now_atts[ 'lang' ] == '') ? get_option( 'booxi_set_def_lang' ) : $book_now_atts[ 'lang' ];
            $label = ($book_now_atts[ 'button_text' ] == '') ? get_option( 'booxi_set_def_label' ) : $book_now_atts[ 'button_text' ];
            $key = ($book_now_atts[ 'api_key' ] == '') ? get_option( 'booxi_set_api_key' ) : $book_now_atts[ 'api_key' ];

            $output = '<div class="bxw_button" data-lang="'.$lang.'" data-key="'.$key.'" onclick="bxe_core.clickBMW(this);" ico>';
            $output .= $label;
            $output .= '</div>';

            return $output;
        }


        /**
         * Activate the plugin
         */
        public static function activate()
        {
            // Do nothing
        }

        /**
         * Deactivate the plugin
         */
        public static function deactivate()
        {
            // Do nothing
        }

    }
    //////////////
}

if(class_exists('booxi_api'))
{
    // Installation and uninstallation hooks
    register_activation_hook(__FILE__, array('booxi_api', 'activate'));
    register_deactivation_hook(__FILE__, array('booxi_api', 'deactivate'));

    // instantiate the plugin class
    $booxi = new booxi_api();
}


// Add a link to the settings page onto the plugin page
if(isset($booxi))
{
    // Add the settings link to the plugins page
    function plugin_settings_link($links)
    {
        $settings_link = '<a href="options-general.php?page=booxi_api">Settings</a>';
        array_unshift($links, $settings_link);
        return $links;
    }

    $plugin = plugin_basename(__FILE__);
    add_filter("plugin_action_links_$plugin", 'plugin_settings_link');
}