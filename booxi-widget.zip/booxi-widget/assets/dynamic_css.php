<style type="text/css">
    @import url(https://fonts.googleapis.com/css?family=Titillium+Web);

    <?php

    $showIcon = (get_option( 'booxi_set_show_icon' ) == 'true') ? true : false;
    $borderRadius = intval(get_option( 'booxi_set_border_radius' ));
    $fontSize = intval(get_option( 'booxi_set_font_size' ));
    $lineHeight = intval(get_option( 'booxi_set_height' ));
    $paddingSize= intval(get_option( 'booxi_set_padding' ));
    $textColor = get_option( 'booxi_set_col_text' );
    $bkgCol = get_option( 'booxi_set_col_bkg' );
    $borderCol = get_option( 'booxi_set_col_border' );

    $hov_textColor = get_option( 'booxi_set_hov_col_text' );
    $hov_bkgCol = get_option( 'booxi_set_hov_col_bkg' );
    $hov_borderCol = get_option( 'booxi_set_hov_col_border' );

    $custom_css = get_option( 'booxi_set_custom_css' );
    $hov_custom_css = get_option( 'booxi_set_hov_custom_css' );

    ?>

    .bxw_button
    {
        font-family: 'Titillium Web', sans-serif;
        position: relative;
        display: inline-block;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        width:auto;
        line-height:<?php echo $lineHeight; ?>px;
        font-size: <?php echo $fontSize; ?>px;
        padding-left: <?php echo $paddingSize; ?>px;
        padding-right: <?php echo $paddingSize; ?>px;
        border-style: solid;
        border-width: 1px;
        border-color: <?php echo $borderCol; ?>;
        background-color: <?php echo $bkgCol; ?>;
        color: <?php echo $textColor; ?>;
        border-radius: <?php echo $borderRadius; ?>px;
        vertical-align: middle;
        cursor: pointer;

        -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,0.20);
        -moz-box-shadow: 0 1px 1px 0 rgba(0,0,0,0.20);
        box-shadow: 0 1px 1px 0 rgba(0,0,0,0.20);

    <?php echo $custom_css; ?>
    }

    .bxw_button:hover
    {
        border-color: <?php echo $hov_borderCol; ?>;
        background-color: <?php echo $hov_bkgCol; ?>;
        color: <?php echo $hov_textColor; ?>;

    <?php echo $hov_custom_css; ?>
    }

    <?php
    if($showIcon)
    {
    ?>

    .bxw_button[ico]
    {
        padding-right: <?php echo $paddingSize + 40; ?>px;
    }

    .bxw_button[ico]::after
    {
        content: '';
        position: absolute;
        top:0;
        right:0;
        bottom:0;
        width: <?php echo $paddingSize + 40; ?>px;
        background-position: center center;
        background-repeat: no-repeat;
        background-image: url('https://www.booxi.com/img/icons/svg/book_w.svg');
    }

    <?php
    }
    ?>

    #bx-viewport, .bx_viewport
    {
        position:fixed;
        display:none;
        left: 0;
        top:0;
        right: 0;
        bottom: 0;
        background-color: rgba(238, 238, 238, 0.85);
        z-index: 999;
    }

    #bx-viewport iframe, .bx_viewport
    {
        display: none;
        width:100%;
        height:100%;
    }


    #bx-viewport[is_open=true], #bx-viewport[is_open=loading], .bx_viewport[is_open=true], .bx_viewport[is_open=loading]
    {
        display:block;
    }

    #bx-viewport[is_open=true] iframe, .bx_viewport[is_open=true] iframe
    {
        display: block;
    }

    #bx-viewport[is_open=true] .loading_bar, .bx_viewport[is_open=true] .loading_bar
    {
        display: none;
    }

    .loading_bar
    {
        width: 100%;
        height:100%;

        background-repeat: no-repeat;
        background-position: center;
        background-image: url(https://www.booxi.com/img/icons/gif/loading_green_circle.gif);
    }

    #bx-viewport[is_open=true] .loading_bar
    {
        display: none;
    }




</style>