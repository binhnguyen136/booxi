<?php

$lang_options = array('eng' => 'English', 'fre' => 'Francais');
$ext_win_options = array('false' => 'Display in page', 'true' => 'Display as popup');
$show_icon_options = array('true' => 'Yes', 'false' => 'No');

?>


<div class="wrap">
    <h2>Booxi Api Settings</h2>
    <form method="post" action="options.php">
        <?php @settings_fields('booxi_api-group'); ?>
        <?php @do_settings_fields('booxi_api-group'); ?>


        <h3>Book Now Default Settings</h3>
        <table class="form-table">
            <tr valign="top">
                <th scope="row"><label for="booxi_set_api_key">Default API Key (optional)</label></th>
                <td><input type="text" name="booxi_set_api_key" id="booxi_set_api_key" value="<?php echo get_option('booxi_set_api_key'); ?>" size="35" /></td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="booxi_set_def_lang">Default Language</label></th>
                <td>
                    <select name="booxi_set_def_lang" id="booxi_set_def_lang">
                        <?php
                        $sel_lang = get_option('booxi_set_def_lang');
                        foreach ($lang_options as $key => $value)
                        {
                            $is_sel = ($key == $sel_lang) ? " selected" : '';
                            echo '<option value="'.$key.'"'.$is_sel.'>'.$value.'</option>';
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="booxi_set_def_label">Default Button Label</label></th>
                <td><input type="text" name="booxi_set_def_label" id="booxi_set_def_label" value="<?php echo get_option('booxi_set_def_label'); ?>" /></td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="booxi_set_ext_window">Book Now Widget Display</label></th>
                <td>
                    <select name="booxi_set_ext_window" id="booxi_set_ext_window">
                        <?php
                        $sel_ext_win = get_option('booxi_set_ext_window');
                        foreach ($ext_win_options as $key => $value)
                        {
                            $is_sel = ($key == $sel_lang) ? " selected" : '';
                            echo '<option value="'.$key.'"'.$is_sel.'>'.$value.'</option>';
                        }
                        ?>
                    </select>
                </td>
            </tr>
        </table>

        <hr>
        <h3>Button Appearance Settings</h3>
        <table class="form-table">
            <tr valign="top">
                <th scope="row"><label for="booxi_set_show_icon">Display Button Icon</label></th>
                <td>
                    <select name="booxi_set_show_icon" id="booxi_set_show_icon">
                        <?php
                        $sel_op = get_option('booxi_set_show_icon');
                        foreach ($show_icon_options as $key => $value)
                        {
                            $is_sel = ($key == $sel_op) ? " selected" : '';
                            echo '<option value="'.$key.'"'.$is_sel.'>'.$value.'</option>';
                            //booxi_set_border_radius
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="booxi_set_border_radius">Border Radius</label></th>
                <td><input type="text" name="booxi_set_border_radius" id="booxi_set_border_radius" value="<?php echo get_option('booxi_set_border_radius'); ?>" size="2" /><span>PX</span></td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="booxi_set_font_size">Font Size</label></th>
                <td><input type="text" name="booxi_set_font_size" id="booxi_set_font_size" value="<?php echo get_option('booxi_set_font_size'); ?>" size="2" /><span>PX</span></td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="booxi_set_height">Button Height</label></th>
                <td><input type="text" name="booxi_set_height" id="booxi_set_height" value="<?php echo get_option('booxi_set_height'); ?>" size="2" /><span>PX</span></td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="booxi_set_padding">Left / Right Padding</label></th>
                <td><input type="text" name="booxi_set_padding" id="booxi_set_padding" value="<?php echo get_option('booxi_set_padding'); ?>" size="2" /><span>PX</span></td>
            </tr>

            <tr valign="top">
                <th scope="row"><label for="booxi_set_col_text">Text Color</label></th>
                <td><input type="text" class="bxw-color-field" name="booxi_set_col_text" id="booxi_set_col_text" value="<?php echo get_option('booxi_set_col_text'); ?>" data-default-color="#ffffff" /></td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="booxi_set_col_bkg">Background Color</label></th>
                <td><input type="text" class="bxw-color-field" name="booxi_set_col_bkg" id="booxi_set_def_label" value="<?php echo get_option('booxi_set_col_bkg'); ?>" data-default-color="#4ed066" /></td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="booxi_set_col_border">Border Color</label></th>
                <td><input type="text" class="bxw-color-field" name="booxi_set_col_border" id="booxi_set_col_border" value="<?php echo get_option('booxi_set_col_border'); ?>" data-default-color="#308c42" /></td>
            </tr>

            <tr valign="top">
                <th scope="row"><label for="booxi_set_custom_css">Custom CSS</label></th>
                <td><textarea name="booxi_set_custom_css" id="booxi_set_custom_css" rows="6" cols="50"><?php echo get_option('booxi_set_custom_css'); ?></textarea></td>
            </tr>

            <tr valign="top">
                <td><h3>Button Hover State</h3></td>
            </tr>

            <tr valign="top">
                <th scope="row"><label for="booxi_set_hov_col_text">Text Color</label></th>
                <td><input type="text" class="bxw-color-field" name="booxi_set_hov_col_text" id="booxi_set_hov_col_text" value="<?php echo get_option('booxi_set_hov_col_text'); ?>" data-default-color="#ffffff" /></td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="booxi_set_hov_col_bkg">Background Color</label></th>
                <td><input type="text" class="bxw-color-field" name="booxi_set_hov_col_bkg" id="booxi_set_hov_col_bkg" value="<?php echo get_option('booxi_set_hov_col_bkg'); ?>" data-default-color="#3ebd55" /></td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="booxi_set_hov_col_border">Border Color</label></th>
                <td><input type="text" class="bxw-color-field" name="booxi_set_hov_col_border" id="booxi_set_col_border" value="<?php echo get_option('booxi_set_hov_col_border'); ?>" data-default-color="#38AC4E" /></td>
            </tr>
            <tr valign="top">
                <th scope="row"><label for="booxi_set_hov_custom_css">Custom CSS</label></th>
                <td><textarea name="booxi_set_hov_custom_css" id="booxi_set_hov_custom_css" rows="6" cols="50"><?php echo get_option('booxi_set_hov_custom_css'); ?></textarea></td>
            </tr>

        </table>

        <?php @submit_button(); ?>
    </form>
</div>